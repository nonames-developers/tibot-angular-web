import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-manual',
  templateUrl: './control-manual.component.html',
  styleUrls: ['./control-manual.component.css']
})
export class ControlManualComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
